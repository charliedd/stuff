import java.util.Arrays;

public class FastCollinearPoints {
	private LineSegment[] lineSegments;
	
   public FastCollinearPoints(Point[] points){
	   
	   if (points == null)throw new java.lang.IllegalArgumentException();
		
		int size = points.length;
		
		if(points[size-1] == null)throw new java.lang.IllegalArgumentException();
		
		for (int i = 0;i < size - 1; i++ ){
			if(points[i] == null)throw new java.lang.IllegalArgumentException();
			for (int j = i + 1; j < size; j++){
				if(points[i].compareTo(points[j]) == 0) throw new java.lang.IllegalArgumentException();
			}
		}
		
		

		int sizeTemp = size * size;
		
		Point[] startPoints = new Point[sizeTemp];
		Point[] endPoints = new Point[sizeTemp];
		
		int posIndex = 0;
		
		Point[] tempPoints = points.clone();
		
		for (int i = 0; i < size; i++){
			 Arrays.sort(tempPoints, points[i].slopeOrder());
			 
			 
			 Point p = tempPoints[0];
			 
			 Point q = tempPoints[1];
			 Point r = tempPoints[2];
			 Point s = tempPoints[3]; 
			 Point t = tempPoints[size-1];
			 Point u = tempPoints[size-2];
			 Point v = tempPoints[size-3];
			 
			 
			 Point[] linePoints = {p,q,r,s};
			 Arrays.sort(linePoints);
			 
			 Point[] linePoints2 = {p,t,u,v};
			 Arrays.sort(linePoints2);
			 
			  if (isCollinear(p,q,r,s)){
				   if (posIndex == 0){
					   startPoints[posIndex] = linePoints[0] ;
					   endPoints[posIndex] = linePoints[3];
					   posIndex++;
				   }else{
					   boolean exists = false;
					   for(int n = 0; n < posIndex; n++){
						   if(startPoints[n] == linePoints[0] && endPoints[n] == linePoints[3] ){
							   exists = true;
							   break;
						   }
					   }
					   
					   if(!exists){
						   startPoints[posIndex] = linePoints[0];
						   endPoints[posIndex] = linePoints[3];
						   posIndex++;
					   }
				   }
				 
			   }
			  
				  if (isCollinear(p,t,u,v)){
				
					   if (posIndex == 0){
						   startPoints[posIndex] = linePoints2[0] ;
						   endPoints[posIndex] = linePoints2[3];
						   posIndex++;
					   }else{
						   boolean exists = false;
						   for(int n = 0; n < posIndex; n++){
							   if(startPoints[n] == linePoints2[0] && endPoints[n] == linePoints2[3] ){
								   exists = true;
								   break;
							   }
						   }
						   
						   if(!exists){
							   startPoints[posIndex] = linePoints2[0];
							   endPoints[posIndex] = linePoints2[3];
							   posIndex++;
						   }
					   }
				  }
		}
		
			lineSegments = new LineSegment[posIndex];
		
			for (int i = 0; i < posIndex; i++){
			
			Point startPos = startPoints[i];
			Point endPos = endPoints[i];
			lineSegments[i] = new LineSegment(startPos,endPos);
			
	}
	
		
	   // finds all line segments containing 4 or more points
   }
   public           int numberOfSegments(){
	   return lineSegments.length;
	   // the number of line segments
   }
   public LineSegment[] segments(){
	   return lineSegments;
	   // the line segments
   }
   
   private boolean isCollinear(Point p,Point q,Point r, Point s){
		double pq =  p.slopeTo(q);
		double pr = p.slopeTo(r);
		double ps = p.slopeTo(s);
		
		if(pq == pr && pq == ps)return true;
		else return false;
		
	}
}
